#!/bin/bash
 python 2dImage.py 
